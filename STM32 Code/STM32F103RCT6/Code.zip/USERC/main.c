#include "stm32f10x.h"
#include "Infrared_module.h"
#include "LED.h"


int main(void)
{
    LED_Init();//LED初始化(PB4)
    Infrared_module_Init();//红外模块初始化(PA1)
    
    while(1)
    {
        if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == Bit_RESET)//判断红外模块是否遇到障碍物
        {
            
            GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_SET);//LED 亮
        }
        else
        {
                GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_RESET);//LED 灭
        }
    }
}
