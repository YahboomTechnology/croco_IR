#ifndef __INFRARED_MOUDLE_H__
#define __INFRARED_MOUDLE_H__

#include "stm32f10x.h"

void Infrared_module_Init(void);//红外模块初始化(PA1)

#endif
